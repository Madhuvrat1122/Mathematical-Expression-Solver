from flask import Flask, render_template, request,jsonify,url_for
from test import solve
app = Flask(__name__)

import pickle


with open('pickles/solution_evaluator.pkl','rb') as f1:
    solution_evaluator = pickle.load(f1)
    

with open('pickles/Equation_creator.pkl','rb') as f1:
    Equation_creator = pickle.load(f1)
    

with open('pickles/variable.pkl','rb') as f1:
    variable = pickle.load(f1)

from sympy import *
q,w,e,r,t,y,u,i,o,p = variable("q w e r t y u i o p")
a,s,d,f,g,h,j,k,l = variable("a s d f g h j k l")
z,x,c,v,b,n,m = variable("z x c v b n m")
Q,W,E,R,T,Y,U,I,O,P = variable("Q W E R T Y U I O P")
A,Q,S,D,F,G,H,J,K,L = variable("A Q S D F G H J K L")
Z,X,C,V,B,N,M = variable("Z X C V B N M")


@app.route("/")
def view_template():
    return render_template("index.html")

@app.route("/imgtext")
def home():
    return render_template("imgtext.html")

@app.route("/data", methods=["GET","POST"])
def form_data():
    if request.method == "GET":
        return "<h1>Sorry, You mistaken somewhere</h1>"
    else:
        user_data = request.form   #take data from form in html page
        selected = user_data['selected']
        if int(selected)==0:
            imge = solve(user_data["img_name"])   
            print(imge)
            result=imge[1]
            return jsonify(msg=str(result))
        elif int(selected)==1:
            text = user_data["text_area"]
            result = eval(text)
            return jsonify(msg=str(result))

@app.route("/data1", methods=["GET","POST"])
def form_data1():
    if request.method == "GET":
        return "<h1>Sorry, You mistaken somewhere</h1>"
    else:
        user_data = request.form   
        selected = user_data['selected']
        
        if int(selected)==3:
            imge = user_data["img_name10"]
        
            import pytesseract
            
            pytesseract.pytesseract.tesseract_cmd = 'c:\\program files\\Tesseract-OCR\\tesseract.exe'
    
            from PIL import Image
           
            
            image = Image.open("expression\\"+imge)
            
            
            text = pytesseract.image_to_string(image)
            
            text = text.strip()
                
            
            text = text.replace("^","**")
            # Evaluating Expression
            
            try:
                
                result = eval(text)
            
            except:
                
                try:
                    
                
                    variables = {}
                    
                    var = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'
                    
                    equations = text.split("\n")
                    
                    left = []
                    right = []
                    for eq in equations:
                        a = eq.index('=')
                        print(a)
                        left.append(eq[:a])
                        right.append(eq[a+1:])
                    
                    for char in text:
                        if char in var:
                            if variables.get(char):
                                variables[char] += 1
                            variables[char] = 1
                    
                    
                    q,w,e,r,t,y,u,i,o,p = variable("q w e r t y u i o p")
                    a,s,d,f,g,h,j,k,l = variable("a s d f g h j k l")
                    z,x,c,v,b,n,m = variable("z x c v b n m")
                    Q,W,E,R,T,Y,U,I,O,P = variable("Q W E R T Y U I O P")
                    A,Q,S,D,F,G,H,J,K,L = variable("A Q S D F G H J K L")
                    Z,X,C,V,B,N,M = variable("Z X C V B N M")
                    
                    query = "solution_evaluator(["
                    
                    for i in range(len(equations)):
                        query = query + 'Equation_creator('+str(left[i])+','+str(right[i])+'),'
                    
                    query = query[:-1] + '], ['
                    
                    
                    for v in variables.keys():
                        query = query + v + ','
                    
                    query = query[:-1] + '])'
        
                    result = eval(query)
                
                except:
                    
                    result = "It cannot be evaluated"
                
            return jsonify(msg=str(result).replace('**','^')) 

        



if __name__ == "__main__":
  app.run(debug=False,port=8000)